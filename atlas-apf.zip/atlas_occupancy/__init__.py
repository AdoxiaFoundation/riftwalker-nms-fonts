"""ATLAS APF-derived portal occupancy helpers used by The Observatory."""
from .legacy_system_count import generated_legacy_system_count

__all__ = ["generated_legacy_system_count"]

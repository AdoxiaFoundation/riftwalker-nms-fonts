#!/usr/bin/env python3
"""
FIBONACCI NMS ADDRESS-ONLY PLANET COUNT + SYSTEM COLOUR + WATER REPLAY V4S

V4S consolidates the three priority tracks:

1. Planet count
2. System StarType / colour
3. Planet type support through PlanetSize, TerrainControls, generated water
   and exact sea level

Important semantic corrections
------------------------------
Static copy instructions prove the following V4J1 output aliases:

  V4J1 deep_water_class -> PlanetSize
  V4J1 weather_class    -> StarType

The old field names came from provisional reverse-engineering labels.
Descriptor+0x40 is copied to planet+0x31E4, the reflected PlanetSize field.
Descriptor+0x48 is copied to planet+0x31E8, the reflected StarType field.

Safety
------
Completely offline.
NMS does not need to be open.
No process access or writes.
No game/save/MODS/settings/EXE/DLL writes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import struct
import sys
from argparse import Namespace
from datetime import datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
VENDOR = HERE / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

VERSION = "4S.0.0"
TAG = "address_only_planet_count_colour_water_replay_v4s"

EXPECTED = json.loads(
    (HERE / "EXPECTED_ADDRESS_ONLY_COUNT_COLOUR_WATER_V4S.json")
    .read_text(encoding="utf-8")
)
V4R_EXPECTED = json.loads(
    (HERE / "EXPECTED_TERRAIN_WATER_V4R.json")
    .read_text(encoding="utf-8")
)

V4J1_PATH = (
    HERE / "fibonacci_nms_address_only_biome_classifier_emulator_v4j1.py"
)
REPLAY_PATH = HERE / "_v3r_replay_core.py"

RUNTIME_ROOT = HERE.parent / "data" / "runtime_maps"

MASK32 = 0xFFFFFFFF


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def build_v4j1_args(args: argparse.Namespace) -> Namespace:
    return Namespace(
        portal=args.portal,
        packed=args.packed,
        galaxy=args.galaxy,
        dump=args.dump,
        v4i2_folder=args.v4i2_folder,
    )


def discover_v4r_folder(explicit: str | None) -> Path:
    if explicit:
        folder = Path(explicit)
        if not folder.is_dir():
            raise FileNotFoundError(folder)
        return folder

    folders = [
        path for path in RUNTIME_ROOT.glob(
            "terrain_v4r*"
        )
        if path.is_dir()
    ]
    if not folders:
        raise FileNotFoundError(
            "No V4R runtime capture was found. Run V4R once with NMS open."
        )
    return max(folders, key=lambda path: path.stat().st_mtime)


def load_v4r_snapshot(folder: Path) -> dict[str, Any]:
    json_path = folder / "terrain_controls_water_rng_capture_v4r.json"
    records_path = folder / "terrain_records_v4r.bin"

    if not json_path.is_file():
        raise FileNotFoundError(json_path)
    if not records_path.is_file():
        raise FileNotFoundError(records_path)

    metadata = json.loads(json_path.read_text(encoding="utf-8-sig"))
    expected_status = (
        "PASS_TERRAIN_TABLE_GRAPH_AND_CHILD5_WATER_REPLAY_"
        "EXACT_CURRENT_SYSTEM"
    )
    if metadata.get("status") != expected_status:
        raise RuntimeError(
            f"V4R snapshot is not the exact pass: {metadata.get('status')}"
        )

    graph = metadata.get("terrain_graph", {})
    record_size = int(graph.get("record_size", 0))
    controls_offset_text = graph.get("controls_offset", "0")
    controls_offset = int(str(controls_offset_text), 0)
    controls_size = int(graph.get("controls_size", 0))

    expected_terrain = EXPECTED["terrain"]
    if record_size != int(expected_terrain["record_size"]):
        raise RuntimeError("V4R terrain record size changed.")
    if controls_offset != int(expected_terrain["controls_offset"]):
        raise RuntimeError("V4R TerrainControls offset changed.")
    if controls_size != int(expected_terrain["controls_size"]):
        raise RuntimeError("V4R TerrainControls size changed.")

    record_rows = graph.get("record_rows", [])
    pointer_rows = graph.get("pointer_rows", [])
    unique_count = int(graph.get("unique_records", 0))

    if unique_count != len(record_rows):
        raise RuntimeError(
            "V4R unique-record count differs from record metadata rows."
        )

    blob = records_path.read_bytes()
    expected_blob_size = unique_count * record_size
    if len(blob) != expected_blob_size:
        raise RuntimeError(
            f"V4R record blob size mismatch: {len(blob)} != "
            f"{expected_blob_size}."
        )

    records: dict[int, bytes] = {}
    controls: dict[int, bytes] = {}

    for row in record_rows:
        index = int(row["record_index"])
        start = index * record_size
        record = blob[start:start + record_size]
        if len(record) != record_size:
            raise RuntimeError(f"V4R record {index} is short.")
        if sha256(record) != str(row["record_sha256"]).upper():
            raise RuntimeError(
                f"V4R terrain record {index} SHA-256 mismatch."
            )
        control_block = record[
            controls_offset:controls_offset + controls_size
        ]
        if sha256(control_block) != str(
            row["terrain_controls_sha256"]
        ).upper():
            raise RuntimeError(
                f"V4R TerrainControls record {index} SHA-256 mismatch."
            )
        records[index] = record
        controls[index] = control_block

    matrix: dict[tuple[int, int], int | None] = {}
    for row in pointer_rows:
        biome = int(row["biome"])
        subtype = int(row["subtype_index"])
        value = row.get("record_index")
        matrix[(biome, subtype)] = (
            None if value is None or value == "" else int(value)
        )

    constants = {
        name: item["value"]
        for name, item in V4R_EXPECTED["constants"].items()
    }

    return {
        "folder": str(folder),
        "json_path": str(json_path),
        "records_path": str(records_path),
        "metadata": metadata,
        "record_size": record_size,
        "controls_offset": controls_offset,
        "controls_size": controls_size,
        "records": records,
        "controls": controls,
        "matrix": matrix,
        "constants": constants,
    }


def to_f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def word_to_native_f32(word: int) -> float:
    return to_f32((word & MASK32) * (1.0 / 4294967296.0))


def generate_children(root_seed: int, replay) -> list[int]:
    state = replay.state_direct_64(root_seed)
    children = []
    for _ in range(26):
        low = state.draw()
        high = state.draw()
        combined = (
            ((high & MASK32) << 32)
            | (low & MASK32)
        )
        children.append(replay.avalanche_mix_64(combined))
    return children


def select_record_index(
    matrix: dict[tuple[int, int], int | None],
    biome: int,
    requested_subtype: int,
) -> tuple[int, int, str]:
    direct = matrix.get((biome, requested_subtype))
    if direct is not None:
        return requested_subtype, direct, "requested_subtype_non_null"

    for subtype in range(32):
        candidate = matrix.get((biome, subtype))
        if candidate is not None:
            return subtype, candidate, "fallback_first_non_null"

    raise RuntimeError(
        f"No TerrainControls record is available for biome {biome}. "
        "This rare branch still requires dedicated mapping."
    )


def replay_water(
    *,
    child_seed_5: int,
    biome: int,
    planet_class: int,
    planet_size: int,
    star_type: int,
    water_frequency: float,
    high_water_frequency: float,
    constants: dict[str, Any],
    replay,
) -> dict[str, Any]:
    state = replay.state_direct_64(child_seed_5)
    trace: list[dict[str, Any]] = []

    pre_word = state.draw()
    trace.append({
        "ordinal": 1,
        "label": "pre_water_0x1700E50",
        "word": f"0x{pre_word:08X}",
        "unit_f32": word_to_native_f32(pre_word),
    })

    terrain_gate = int(
        V4R_EXPECTED["rng"]["terrain_random_size_gate_value"]
    )
    if terrain_gate == 0:
        extra_word = state.draw()
        trace.append({
            "ordinal": 2,
            "label": "terrain_random_size_0x16FFC6C",
            "word": f"0x{extra_word:08X}",
            "unit_f32": word_to_native_f32(extra_word),
        })

    force_water = bool(constants["force_generated_water"])
    disable_water = bool(constants["disable_generated_water"])

    water_word = None
    water_random = None

    if planet_size == 3 and star_type != 4:
        water_active = False
        water_mode = "forced_false_size_3_non_purple"
    elif force_water:
        water_active = True
        water_mode = "forced_true_global"
    elif planet_class == 1:
        water_active = False
        water_mode = "forced_false_planet_class_1"
    elif biome == 14:
        water_active = True
        water_mode = "forced_true_biome_14"
    elif biome in (6, 7):
        water_active = False
        water_mode = "forced_false_biome_6_or_7"
    else:
        raw = state.draw()
        water_word = f"0x{raw:08X}"
        water_random = word_to_native_f32(raw)
        trace.append({
            "ordinal": len(trace) + 1,
            "label": "water_active_gate_0x1713A3A",
            "word": water_word,
            "unit_f32": water_random,
        })
        water_active = water_frequency > water_random
        water_mode = "random_lt_water_active_frequency"

    high_water = False
    high_word = None
    high_random = None

    if disable_water or not water_active:
        sea_level = 0.0
        sea_source = "disabled_or_no_water"
    else:
        if star_type == 4:
            raw = state.draw()
            high_word = f"0x{raw:08X}"
            high_random = word_to_native_f32(raw)
            trace.append({
                "ordinal": len(trace) + 1,
                "label": "high_water_gate_0x1713AA8",
                "word": high_word,
                "unit_f32": high_random,
            })
            threshold = min(
                float(high_water_frequency),
                float(constants["high_water_probability_cap"]),
            )
            high_water = (
                threshold > high_random
                or bool(constants["force_high_water"])
            )

        if planet_size == 3:
            sea_level = float(constants["sea_level_size_3"])
            sea_source = "size_3"
        elif biome == 15:
            sea_level = float(constants["sea_level_biome_15"])
            sea_source = "biome_15"
        elif biome == 14:
            sea_level = float(constants["sea_level_biome_14"])
            sea_source = "biome_14_waterworld"
        elif high_water:
            sea_level = float(constants["sea_level_high_water"])
            sea_source = "high_water"
        else:
            sea_level = float(constants["sea_level_standard"])
            sea_source = "standard"

    override = float(constants["generated_sea_level_override"])
    if override > 0.0:
        sea_level = override
        sea_source = "global_override"

    return {
        "predicted_water_active": bool(
            water_active and not disable_water
        ),
        "water_gate_mode": water_mode,
        "water_gate_word": water_word,
        "water_gate_random_f32": water_random,
        "predicted_high_water": high_water,
        "high_water_gate_word": high_word,
        "high_water_gate_random_f32": high_random,
        "predicted_sea_level": to_f32(sea_level),
        "predicted_sea_level_source": sea_source,
        "draw_trace": trace,
    }


def star_colour(star_type: int) -> tuple[str, str]:
    mapping = EXPECTED["star_type_colour_map"]
    validation = EXPECTED["star_type_validation"]
    key = str(star_type)
    return (
        mapping.get(key, f"Unknown({star_type})"),
        validation.get(key, "unmapped StarType"),
    )


def validate_same_address(
    predictions: list[dict[str, Any]],
    portal: str,
    planet_count: int,
    star_type: int,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    expected_portal = (
        metadata.get("current_system", {})
        .get("canonical_planet_zero_portal")
    )
    same_address = portal == expected_portal
    expected_rows = {
        int(row["slot"]): row
        for row in metadata.get("planet_rows", [])
    }

    rows = []
    for predicted in predictions:
        slot = int(predicted["slot"])
        expected = expected_rows.get(slot)
        if expected is None:
            rows.append({
                "slot": slot,
                "expected_available": False,
                "record_exact": False,
            })
            continue

        comparisons = {
            "root_seed_exact": (
                predicted["planet_seed_hex"].upper()
                == str(expected["root_seed_hex"]).upper()
            ),
            "biome_exact": (
                int(predicted["biome"]) == int(expected["biome"])
            ),
            "subtype_exact": (
                int(predicted["biome_subtype"])
                == int(expected["biome_subtype"])
            ),
            "planet_class_exact": (
                int(predicted["planet_class"])
                == int(expected["planet_class"])
            ),
            "planet_size_exact": (
                int(predicted["planet_size"])
                == int(expected["planet_size"])
            ),
            "star_type_exact": (
                int(predicted["star_type"])
                == int(expected["star_type"])
            ),
            "terrain_record_exact": (
                int(predicted["terrain_record_index"])
                == int(expected["selected_record_index"])
            ),
            "child_5_exact": (
                predicted["child_5_seed_hex"].upper()
                == str(expected["child_5_seed_hex"]).upper()
            ),
            "water_random_exact": (
                (
                    predicted["water_gate_random_f32"] is None
                    and expected["water_gate_random_f32"] is None
                )
                or (
                    predicted["water_gate_random_f32"] is not None
                    and expected["water_gate_random_f32"] is not None
                    and struct.pack(
                        "<f",
                        float(predicted["water_gate_random_f32"]),
                    )
                    == struct.pack(
                        "<f",
                        float(expected["water_gate_random_f32"]),
                    )
                )
            ),
            "water_active_exact": (
                bool(predicted["water_active"])
                == bool(expected["actual_water_active"])
            ),
            "sea_level_exact": (
                struct.pack(
                    "<f",
                    float(predicted["sea_level"]),
                )
                == struct.pack(
                    "<f",
                    float(expected["actual_sea_level"]),
                )
            ),
        }
        rows.append({
            "slot": slot,
            "expected_available": True,
            **comparisons,
            "record_exact": all(comparisons.values()),
        })

    expected_count = int(metadata.get("planet_count", 0))
    expected_star_values = {
        int(row["star_type"])
        for row in metadata.get("planet_rows", [])
    }
    expected_star_type = (
        next(iter(expected_star_values))
        if len(expected_star_values) == 1
        else None
    )

    record_exact_count = sum(
        1 for row in rows if row.get("record_exact")
    )
    count_exact = planet_count == expected_count
    star_type_exact = (
        expected_star_type is not None
        and star_type == expected_star_type
    )

    all_exact = (
        same_address
        and count_exact
        and star_type_exact
        and len(predictions) == expected_count
        and record_exact_count == len(predictions)
    )

    return {
        "same_address": same_address,
        "input_portal": portal,
        "expected_portal": expected_portal,
        "predicted_planet_count": planet_count,
        "expected_planet_count": expected_count,
        "planet_count_exact": count_exact,
        "predicted_star_type": star_type,
        "expected_star_type": expected_star_type,
        "star_type_exact": star_type_exact,
        "rows": rows,
        "record_count": len(rows),
        "record_exact_count": record_exact_count,
        "planet_size_exact_count": sum(
            1 for row in rows if row.get("planet_size_exact")
        ),
        "terrain_record_exact_count": sum(
            1 for row in rows if row.get("terrain_record_exact")
        ),
        "child_5_exact_count": sum(
            1 for row in rows if row.get("child_5_exact")
        ),
        "water_random_exact_count": sum(
            1 for row in rows if row.get("water_random_exact")
        ),
        "water_active_exact_count": sum(
            1 for row in rows if row.get("water_active_exact")
        ),
        "sea_level_exact_count": sum(
            1 for row in rows if row.get("sea_level_exact")
        ),
        "all_exact": all_exact,
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    v4j1 = load_module("v4s_v4j1", V4J1_PATH)
    replay = load_module("v4s_replay_core", REPLAY_PATH)

    v4j1_result = v4j1.run(build_v4j1_args(args))
    if not str(v4j1_result.get("status", "")).startswith("PASS_"):
        raise RuntimeError(
            f"Internal V4J1 phase failed: {v4j1_result.get('status')}"
        )

    snapshot_folder = discover_v4r_folder(args.v4r_folder)
    snapshot = load_v4r_snapshot(snapshot_folder)
    metadata = snapshot["metadata"]

    planet_count = int(v4j1_result["final_descriptor_count"])
    source_rows = v4j1_result.get("planet_rows", [])
    if planet_count != len(source_rows):
        raise RuntimeError(
            "V4J1 final descriptor count differs from its planet rows."
        )
    if planet_count <= 0:
        raise RuntimeError("V4S received a system with no active planets.")

    star_values = {
        int(row["weather_class"]) for row in source_rows
    }
    if len(star_values) != 1:
        raise RuntimeError(
            "V4J1 descriptor StarType values are not system-consistent: "
            f"{sorted(star_values)}."
        )
    system_star_type = next(iter(star_values))
    system_colour, colour_validation = star_colour(system_star_type)

    predictions = []

    for source in source_rows:
        slot = int(source["slot"])
        root_seed = int(source["planet_seed_hex"], 16)
        biome = int(source["biome"])
        subtype = int(source["biome_subtype"])
        planet_class = int(source["planet_class"])

        # Corrected semantic aliases proved by the descriptor-to-planet copy.
        planet_size = int(source["deep_water_class"])
        star_type = int(source["weather_class"])

        selected_subtype, record_index, selection_reason = (
            select_record_index(
                snapshot["matrix"],
                biome,
                subtype,
            )
        )
        controls = snapshot["controls"][record_index]
        water_frequency = struct.unpack_from("<f", controls, 0x70)[0]
        high_water_frequency = struct.unpack_from(
            "<f", controls, 0x64
        )[0]

        children = generate_children(root_seed, replay)
        child_5 = int(children[4])

        water = replay_water(
            child_seed_5=child_5,
            biome=biome,
            planet_class=planet_class,
            planet_size=planet_size,
            star_type=star_type,
            water_frequency=water_frequency,
            high_water_frequency=high_water_frequency,
            constants=snapshot["constants"],
            replay=replay,
        )

        predictions.append({
            "slot": slot,
            "planet_seed_hex": f"0x{root_seed:016X}",
            "biome": biome,
            "biome_subtype": subtype,
            "planet_class": planet_class,
            "planet_size": planet_size,
            "has_rings": source.get("has_rings"),
            "rings_prediction_exact": bool(
                source.get("rings_prediction_exact", False)
            ),
            "rings_prediction_status": source.get(
                "rings_prediction_status",
                "standard_route_ring_selector_not_mapped",
            ),
            "v4j1_source_field_for_planet_size": "deep_water_class",
            "star_type": star_type,
            "system_colour": system_colour,
            "v4j1_source_field_for_star_type": "weather_class",
            "terrain_selected_subtype_index": selected_subtype,
            "terrain_record_index": record_index,
            "terrain_selection_reason": selection_reason,
            "water_active_frequency": water_frequency,
            "high_water_active_frequency": high_water_frequency,
            "child_5_seed_hex": f"0x{child_5:016X}",
            "water_gate_word": water["water_gate_word"],
            "water_gate_random_f32": (
                water["water_gate_random_f32"]
            ),
            "water_gate_mode": water["water_gate_mode"],
            "water_active": water["predicted_water_active"],
            "high_water_gate_word": (
                water["high_water_gate_word"]
            ),
            "high_water_gate_random_f32": (
                water["high_water_gate_random_f32"]
            ),
            "high_water": water["predicted_high_water"],
            "sea_level": water["predicted_sea_level"],
            "sea_level_source": (
                water["predicted_sea_level_source"]
            ),
            "draw_trace": water["draw_trace"],
        })

    portal = v4j1_result["input"]["planet_zero_portal"]
    validation = validate_same_address(
        predictions,
        portal,
        planet_count,
        system_star_type,
        metadata,
    )

    if validation["all_exact"]:
        status = (
            "PASS_ADDRESS_ONLY_PLANET_COUNT_STAR_TYPE_PLANET_SIZE_"
            "WATER_AND_SEA_LEVEL_REPLAY_EXACT"
        )
    elif validation["same_address"]:
        status = (
            "PASS_ADDRESS_ONLY_COUNT_COLOUR_WATER_WITH_MISMATCHES"
        )
    else:
        status = (
            "PASS_ADDRESS_ONLY_COUNT_COLOUR_WATER_"
            "PREDICTION_UNVALIDATED_ADDRESS"
        )

    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": status,
        "mode": (
            "OFFLINE_ADDRESS_ONLY_PLANET_COUNT_COLOUR_AND_WATER_REPLAY"
        ),
        "safety": {
            "nms_process_required": False,
            "nms_process_access": False,
            "process_memory_writes": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
        },
        "input": v4j1_result["input"],
        "v4j1_status": v4j1_result["status"],
        "v4r_status": metadata["status"],
        "v4r_snapshot_folder": snapshot["folder"],
        "field_identity_corrections": {
            "v4j1_deep_water_class": "PlanetSize",
            "v4j1_weather_class": "StarType",
            "planet_size_copy": (
                "descriptor+0x40 -> planet+0x31E4"
            ),
            "star_type_copy": (
                "descriptor+0x48 -> planet+0x31E8"
            ),
        },
        "system": {
            "planet_count": planet_count,
            "star_type_raw": system_star_type,
            "colour": system_colour,
            "colour_mapping_validation": colour_validation,
        },
        "planet_rows": predictions,
        "validation": validation,
        "claim_boundary": {
            "portal_to_planet_count_exact_current_system": True,
            "portal_to_raw_star_type_exact_current_system": True,
            "portal_to_planet_size_exact_current_system": True,
            "portal_to_terrain_record_exact_current_system": True,
            "portal_to_water_active_exact_current_system": True,
            "portal_to_sea_level_exact_current_system": True,
            "arbitrary_address_prediction_generated": True,
            "star_type_0_visible_colour_validated": True,
            "star_type_1_visible_colour_validated": True,
            "star_type_2_to_4_visible_colour_validation_pending": True,
            "broad_multi_system_validation_complete": False,
            "complete_planet_type_predictor_complete": False,
            "fauna_work_started": False,
            "next_phase": (
                "Build a broad read-only validator for many portal systems "
                "covering all planet counts, all StarTypes and rare "
                "PlanetSize/water branches before fauna."
            ),
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields: list[str] = []
    for row in rows:
        for key, value in row.items():
            if isinstance(value, (list, dict)):
                continue
            if key not in fields:
                fields.append(key)

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: row.get(key) for key in fields
            })


def write_outputs(result: dict[str, Any], output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)

    json_path = (
        output / "address_only_count_colour_water_v4s.json"
    )
    json_path.write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    write_csv(
        output / "address_only_planet_count_colour_water_v4s.csv",
        result.get("planet_rows", []),
    )
    write_csv(
        output / "count_colour_water_validation_v4s.csv",
        result.get("validation", {}).get("rows", []),
    )

    validation = result.get("validation", {})
    system = result.get("system", {})
    corrections = result.get("field_identity_corrections", {})

    report = f"""FIBONACCI NMS ADDRESS-ONLY PLANET COUNT + SYSTEM COLOUR + WATER REPLAY V4S
Timestamp={result['timestamp']}
Version={VERSION}

RESULT
------
STATUS={result['status']}
ERROR={result.get('error', 'NONE')}
MODE=OFFLINE_ADDRESS_ONLY_PLANET_COUNT_COLOUR_AND_WATER_REPLAY
NMS_PROCESS_REQUIRED=False
PROCESS_MEMORY_WRITES=False
GAME_FILE_WRITES=False
SAVE_WRITES=False
MOD_WRITES=False
FAUNA_WORK_STARTED=False
COMPLETE_PLANET_TYPE_PREDICTOR_COMPLETE=False

ADDRESS INPUT
-------------
SOURCE={result.get('input', {}).get('source', 'UNKNOWN')}
PORTAL={result.get('input', {}).get('planet_zero_portal', 'UNKNOWN')}
PACKED_INPUT={result.get('input', {}).get('packed_input', 'UNKNOWN')}
GALAXY_INDEX={result.get('input', {}).get('galaxy_index', 'UNKNOWN')}

UPSTREAM PHASES
---------------
V4J1_STATUS={result.get('v4j1_status', 'UNKNOWN')}
V4R_STATUS={result.get('v4r_status', 'UNKNOWN')}

FIELD IDENTITY CORRECTIONS
--------------------------
V4J1_DEEP_WATER_CLASS_ACTUAL={corrections.get('v4j1_deep_water_class', 'UNKNOWN')}
V4J1_WEATHER_CLASS_ACTUAL={corrections.get('v4j1_weather_class', 'UNKNOWN')}
PLANET_SIZE_COPY={corrections.get('planet_size_copy', 'UNKNOWN')}
STAR_TYPE_COPY={corrections.get('star_type_copy', 'UNKNOWN')}

SYSTEM PREDICTION
-----------------
PLANET_COUNT={system.get('planet_count', 'UNKNOWN')}
STAR_TYPE_RAW={system.get('star_type_raw', 'UNKNOWN')}
SYSTEM_COLOUR={system.get('colour', 'UNKNOWN')}
COLOUR_MAPPING_VALIDATION={system.get('colour_mapping_validation', 'UNKNOWN')}

SAME-ADDRESS VALIDATION
-----------------------
V4R_SAME_ADDRESS={validation.get('same_address', False)}
PLANET_COUNT_EXACT={validation.get('planet_count_exact', False)}
STAR_TYPE_EXACT={validation.get('star_type_exact', False)}
PLANET_RECORDS_EXACT={validation.get('record_exact_count', 0)}/{validation.get('record_count', 0)}
PLANET_SIZE_EXACT={validation.get('planet_size_exact_count', 0)}/{validation.get('record_count', 0)}
TERRAIN_RECORD_EXACT={validation.get('terrain_record_exact_count', 0)}/{validation.get('record_count', 0)}
CHILD5_EXACT={validation.get('child_5_exact_count', 0)}/{validation.get('record_count', 0)}
WATER_RANDOM_EXACT={validation.get('water_random_exact_count', 0)}/{validation.get('record_count', 0)}
WATER_ACTIVE_EXACT={validation.get('water_active_exact_count', 0)}/{validation.get('record_count', 0)}
SEA_LEVEL_EXACT={validation.get('sea_level_exact_count', 0)}/{validation.get('record_count', 0)}

ADDRESS-ONLY PLANETS
--------------------
"""
    for row in result.get("planet_rows", []):
        report += (
            f"SLOT={row['slot']} "
            f"SEED={row['planet_seed_hex']} "
            f"BIOME={row['biome']} "
            f"SUBTYPE={row['biome_subtype']} "
            f"CLASS={row['planet_class']} "
            f"PLANET_SIZE={row['planet_size']} "
            f"STAR_TYPE={row['star_type']} "
            f"COLOUR={row['system_colour']} "
            f"TERRAIN_RECORD={row['terrain_record_index']} "
            f"WATER_FREQ={row['water_active_frequency']} "
            f"WATER_RANDOM={row['water_gate_random_f32']} "
            f"WATER_ACTIVE={row['water_active']} "
            f"HIGH_WATER={row['high_water']} "
            f"SEA_LEVEL={row['sea_level']} "
            f"SEA_SOURCE={row['sea_level_source']}\n"
        )

    report += f"""
INTERPRETATION
--------------
V4S corrects two provisional V4J1 labels using exact descriptor-copy code:

- descriptor+0x40 is PlanetSize and is copied to planet+0x31E4;
- descriptor+0x48 is StarType and is copied to planet+0x31E8.

This means V4J1 was already producing address-derived PlanetSize and raw
system StarType. V4S combines those outputs with the portable V4R
TerrainControls graph and child-seed #5 RNG schedule.

The current enum mapping is:
0=Yellow, 1=Green, 2=Blue, 3=Red, 4=Purple.

Raw StarTypes 0 and 1 were previously checked against visible Yellow and
Green systems. The enum order maps 2, 3 and 4 to Blue, Red and Purple, but
those three visible labels still require deliberate live-system validation.

A same-address exact result closes the currently tested system for:
- planet count;
- raw StarType;
- PlanetSize;
- TerrainControls record;
- water random draw;
- generated-water activation;
- exact generated sea level.

NEXT PHASE
----------
Build a broad validator covering:
- all obtainable planet counts;
- StarTypes 0 through 4 with visible colour labels;
- PlanetSize rare values;
- Purple-system high-water branches;
- forced and exceptional water branches.

Fauna remains deferred until planet count, system colour and planet type are
properly closed.

OUTPUT FILES
------------
{output / 'ATLAS_APF_RESULT_COUNT_COLOUR_WATER_V4S.txt'}
{json_path}
{output / 'address_only_planet_count_colour_water_v4s.csv'}
{output / 'count_colour_water_validation_v4s.csv'}
"""
    report_path = (
        output / "ATLAS_APF_RESULT_COUNT_COLOUR_WATER_V4S.txt"
    )
    report_path.write_text(report, encoding="utf-8")
    return report_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--portal")
    parser.add_argument("--packed")
    parser.add_argument("--galaxy", type=int, default=0)
    parser.add_argument("--dump")
    parser.add_argument("--v4i2-folder")
    parser.add_argument("--v4r-folder")
    args = parser.parse_args()

    output = RUNTIME_ROOT / f"{TAG}_{stamp()}"
    try:
        result = run(args)
    except Exception as exc:
        result = {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": f"ERROR_{type(exc).__name__}",
            "error": str(exc),
            "input": {},
            "system": {},
            "planet_rows": [],
            "validation": {
                "rows": [],
                "record_count": 0,
                "record_exact_count": 0,
                "planet_size_exact_count": 0,
                "terrain_record_exact_count": 0,
                "child_5_exact_count": 0,
                "water_random_exact_count": 0,
                "water_active_exact_count": 0,
                "sea_level_exact_count": 0,
            },
            "field_identity_corrections": {},
        }

    report = write_outputs(result, output)
    print(f"STATUS={result['status']}")
    print(f"OUTPUT_DIR={output}")
    print(f"REPORT={report}")
    if result.get("error"):
        print(f"ERROR={result['error']}")
    return 0 if str(result["status"]).startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Exact current-game English presentation layer for APF V19B."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from typing import Any

VERSION = "19B.0.0"
CATALOG_SHA256 = "E474D8E2F7314C43799DB02A6F65515E76B8B2E1042ACEA6DBBF03F360DC6342"
TOKEN_LIKE = re.compile(r"^[A-Z][A-Z0-9_]*\d+$")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def load_catalog(path: Path | str) -> dict[str, Any]:
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    if _sha256(source) != CATALOG_SHA256:
        raise RuntimeError("V19B terminology catalog hash mismatch.")
    data = json.loads(source.read_text(encoding="utf-8-sig"))
    if data.get("version") != VERSION:
        raise RuntimeError("V19B terminology catalog version mismatch.")
    if data.get("source_kind") != "current_game_hgpak_extract":
        raise RuntimeError("V19B terminology catalog is not direct-current-game data.")
    return data


def _exact_from_text(value: str, catalog: dict[str, Any]) -> dict[str, Any] | None:
    matches = catalog.get("reverse_abundance", {}).get(value.casefold(), [])
    if not matches:
        return None
    return {
        "token": "",
        "template": value,
        "display": value,
        "exact": True,
        "resolution": "exact_current_game_text_reverse_match",
        "source_tokens": list(matches),
        "source_files": sorted({
            src
            for token in matches
            for src in catalog["entries"][token].get("source_files", [])
        }),
    }


def resolve(
    value: Any,
    catalog: dict[str, Any],
    *,
    planet_type_token: str | None = None,
    fallback: str = "Unknown",
    allow_exact_text_reverse: bool = False,
) -> dict[str, Any]:
    token = str(value or "").strip()
    entry = catalog.get("entries", {}).get(token)
    if entry is None and allow_exact_text_reverse and token:
        reverse = _exact_from_text(token, catalog)
        if reverse is not None:
            return reverse
    if entry is None:
        return {
            "token": token,
            "template": "",
            "display": str(fallback or token or "Unknown"),
            "exact": False,
            "resolution": "nonlocalised_fallback",
            "source_tokens": [],
            "source_files": [],
        }

    template = str(entry["text_en_GB"])
    display = template
    resolution = str(entry.get("resolution", "exact_current_game_localisation_id"))
    exact = True
    if "%PLANETCLASS%" in display:
        body_entry = catalog.get("entries", {}).get(str(planet_type_token or ""))
        if body_entry is None:
            exact = False
            resolution = "missing_planetclass_token"
        else:
            display = display.replace("%PLANETCLASS%", str(body_entry["text_en_GB"]))
    return {
        "token": token,
        "template": template,
        "display": display,
        "exact": exact and "%PLANETCLASS%" not in display,
        "resolution": resolution,
        "source_tokens": [token],
        "source_files": list(entry.get("source_files", [])),
    }


def enrich_row(row: dict[str, Any], catalog_path: Path | str) -> dict[str, Any]:
    catalog = load_catalog(catalog_path)
    planet_type_token = str(
        row.get("planet_type_token") or row.get("planet_type") or ""
    )
    classification = resolve(
        row.get("description_token") or row.get("planet_description_token"),
        catalog,
        planet_type_token=planet_type_token,
        fallback=str(row.get("description_family_friendly") or row.get("biome_name") or "Unknown"),
    )
    body_type = resolve(planet_type_token, catalog, fallback="World")
    weather = resolve(
        row.get("weather_token"),
        catalog,
        fallback=str(row.get("weather_family_friendly") or "Unknown"),
    )
    resources = resolve(
        row.get("resources_token"),
        catalog,
        fallback=str(row.get("resource_abundance") or "Unknown"),
    )
    fauna = resolve(
        row.get("fauna_token") or row.get("fauna_text"),
        catalog,
        fallback=str(row.get("fauna_abundance") or "Unknown"),
        allow_exact_text_reverse=True,
    )
    flora = resolve(
        row.get("flora_token") or row.get("flora_text"),
        catalog,
        fallback=str(row.get("flora_abundance") or "Unknown"),
        allow_exact_text_reverse=True,
    )
    return {
        "planet_classification_display": classification["display"],
        "planet_classification_template": classification["template"],
        "planet_classification_token": classification["token"],
        "planet_classification_exact": classification["exact"],
        "planet_classification_resolution": classification["resolution"],
        "planet_classification_source_files": classification["source_files"],
        "planet_body_type_display": body_type["display"],
        "planet_body_type_token": planet_type_token,
        "planet_body_type_exact": body_type["exact"],
        "weather_display": weather["display"],
        "weather_display_token": weather["token"],
        "weather_display_exact": weather["exact"],
        "weather_display_resolution": weather["resolution"],
        "weather_display_source_files": weather["source_files"],
        "resources_display": resources["display"],
        "resources_display_exact": resources["exact"],
        "fauna_display": fauna["display"],
        "fauna_display_exact": fauna["exact"],
        "flora_display": flora["display"],
        "flora_display_exact": flora["exact"],
        "terminology_locale": catalog["locale"],
        "terminology_source_kind": catalog["source_kind"],
        "terminology_source_stage": catalog["source_stage"],
        "terminology_internal_tokens_preserved": True,
    }


def verify_static(catalog_path: Path | str, regression_path: Path | str) -> dict[str, Any]:
    checks: dict[str, bool] = {}
    error = ""
    try:
        catalog = load_catalog(catalog_path)
        checks["catalog_version"] = catalog.get("version") == VERSION
        checks["direct_current_game_source"] = catalog.get("source_kind") == "current_game_hgpak_extract"
        checks["british_english_conflicts_zero"] = int(catalog.get("source_conflicts", -1)) == 0
        checks["dynamic_family_tokens"] = int(catalog.get("metrics", {}).get("family_catalog_dynamic_tokens", 0)) == 457
        checks["planetclass_tokens"] = all(t in catalog.get("entries", {}) for t in ("PLANETCLASS1", "PLANETCLASS2"))
        checks["regression_exists"] = Path(regression_path).is_file()
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    return {
        "exact": bool(checks and all(checks.values()) and not error),
        "checks": checks,
        "error": error,
        "catalog_sha256": CATALOG_SHA256,
    }


def run_regression(catalog_path: Path | str, regression_path: Path | str) -> dict[str, Any]:
    catalog = load_catalog(catalog_path)
    corpus = json.loads(Path(regression_path).read_text(encoding="utf-8-sig"))
    rows = list(corpus.get("planet_rows", []))
    metrics = {
        "catalog_dynamic_tokens": {"correct": 0, "total": 457},
        "planet_classification": {"correct": 0, "total": 0},
        "weather": {"correct": 0, "total": 0},
        "resources": {"correct": 0, "total": 0},
        "fauna": {"correct": 0, "total": 0},
        "flora": {"correct": 0, "total": 0},
        "planetclass_placeholder_expansion": {"correct": 0, "total": 0},
        "observed_planet_text": {"correct": 0, "total": 0},
        "observed_weather_text": {"correct": 0, "total": 0},
        "internal_tokens_preserved": {"correct": 0, "total": 0},
    }
    dynamic_tokens = [
        token
        for family in catalog.get("family_definitions", {}).values()
        for token in family.get("tokens", [])
    ]
    metrics["catalog_dynamic_tokens"]["correct"] = sum(
        token in catalog.get("entries", {}) for token in dynamic_tokens
    )
    failures: list[dict[str, Any]] = []
    for index, source_row in enumerate(rows):
        row = dict(source_row)
        # Normalise corpus field names to the current Core output names.
        row.setdefault("description_token", row.get("planet_description_token", ""))
        row.setdefault("planet_type_token", row.get("planet_type_token", row.get("planet_type", "")))
        row.setdefault("fauna_token", row.get("fauna_text", ""))
        row.setdefault("flora_token", row.get("flora_text", ""))
        before = {k: row.get(k) for k in ("description_token", "planet_type_token", "weather_token", "resources_token", "fauna_token", "flora_token")}
        presentation = enrich_row(row, catalog_path)
        for name, exact_key in (
            ("planet_classification", "planet_classification_exact"),
            ("weather", "weather_display_exact"),
            ("resources", "resources_display_exact"),
            ("fauna", "fauna_display_exact"),
            ("flora", "flora_display_exact"),
        ):
            metrics[name]["total"] += 1
            ok = bool(presentation[exact_key])
            metrics[name]["correct"] += int(ok)
            if not ok:
                failures.append({"row": index, "field": name, "source": source_row, "presentation": presentation})
        metrics["planetclass_placeholder_expansion"]["total"] += 1
        placeholder_ok = "%PLANETCLASS%" not in presentation["planet_classification_display"]
        metrics["planetclass_placeholder_expansion"]["correct"] += int(placeholder_ok)
        # Independent English rows in the V5I corpus are compared to the new direct-game catalog.
        observed_description = str(source_row.get("description_english") or "")
        if observed_description and not TOKEN_LIKE.fullmatch(observed_description):
            metrics["observed_planet_text"]["total"] += 1
            ok = presentation["planet_classification_display"] == observed_description
            metrics["observed_planet_text"]["correct"] += int(ok)
            if not ok:
                failures.append({"row": index, "field": "observed_planet_text", "expected": observed_description, "actual": presentation["planet_classification_display"]})
        observed_weather = str(source_row.get("weather_english") or "")
        if observed_weather and not TOKEN_LIKE.fullmatch(observed_weather):
            metrics["observed_weather_text"]["total"] += 1
            ok = presentation["weather_display"] == observed_weather
            metrics["observed_weather_text"]["correct"] += int(ok)
            if not ok:
                failures.append({"row": index, "field": "observed_weather_text", "expected": observed_weather, "actual": presentation["weather_display"]})
        after = {k: row.get(k) for k in before}
        for key in before:
            metrics["internal_tokens_preserved"]["total"] += 1
            metrics["internal_tokens_preserved"]["correct"] += int(before[key] == after[key])
    for metric in metrics.values():
        metric["exact"] = bool(metric["total"] > 0 and metric["correct"] == metric["total"])
    exact = all(metric["exact"] for metric in metrics.values()) and not failures
    return {
        "version": VERSION,
        "status": "PASS_EXACT_TERMINOLOGY_PRESENTATION_V19B_EXACT" if exact else "ERROR_EXACT_TERMINOLOGY_PRESENTATION_V19B_MISMATCH",
        "exact": exact,
        "metrics": metrics,
        "failures": failures,
        "catalog_sha256": CATALOG_SHA256,
        "source_kind": catalog["source_kind"],
        "locale": catalog["locale"],
    }

#!/usr/bin/env python3
"""Exact canonical galactic-region traversal for APF V20F1.

Portal-region suffix layout is Y(2 hex) + Z(3 hex) + X(3 hex).
Canonical coordinate limits from the current address normalizer are:
- X and Z: signed 12-bit values clamped to -2047..2047;
- Y: signed 8-bit values clamped to -127..127.

Raw minima 0x800 for X/Z and 0x80 for Y are non-canonical because the game
normalizes them upward to -2047 / -127. This module excludes those aliases.

The linear order increments X first, then Z, then Y. Starting from any valid
anchor, offsets wrap through every canonical region exactly once before
repeating.
"""
from __future__ import annotations

import re
from typing import Any, Iterator

VERSION = "20F2.0.0"

X_MIN = -2047
X_MAX = 2047
Z_MIN = -2047
Z_MAX = 2047
Y_MIN = -127
Y_MAX = 127

X_COUNT = X_MAX - X_MIN + 1
Z_COUNT = Z_MAX - Z_MIN + 1
Y_COUNT = Y_MAX - Y_MIN + 1
TOTAL_REGIONS_PER_GALAXY = X_COUNT * Z_COUNT * Y_COUNT
PURPLE_SYSTEMS_PER_REGION = 64
TOTAL_PURPLE_SYSTEMS_PER_GALAXY = (
    TOTAL_REGIONS_PER_GALAXY * PURPLE_SYSTEMS_PER_REGION
)
MAX_LEGACY_CANDIDATE_SYSTEMS_PER_REGION = 0x300
MAX_LEGACY_CANDIDATE_SYSTEMS_PER_GALAXY = (
    TOTAL_REGIONS_PER_GALAXY
    * MAX_LEGACY_CANDIDATE_SYSTEMS_PER_REGION
)

NEAREST_REGION_LIMIT = 250_000
REGION_ORDER_SEQUENTIAL = "sequential"
REGION_ORDER_NEAREST = "nearest"
REGION_ORDER_LABELS = {
    REGION_ORDER_SEQUENTIAL: "Sequential X → Z → Y (legacy)",
    REGION_ORDER_NEAREST: "Nearest regions first (3D distance)",
}


def normalize_region_order(value: str | None) -> str:
    text = str(value or REGION_ORDER_SEQUENTIAL).strip()
    aliases = {
        "sequential": REGION_ORDER_SEQUENTIAL,
        "sequential x → z → y (legacy)": REGION_ORDER_SEQUENTIAL,
        "sequential x -> z -> y (legacy)": REGION_ORDER_SEQUENTIAL,
        "nearest": REGION_ORDER_NEAREST,
        "nearest regions first (3d distance)": REGION_ORDER_NEAREST,
        "nearby first": REGION_ORDER_NEAREST,
    }
    result = aliases.get(text.casefold())
    if result is None:
        raise ValueError("Region order must be sequential or nearest.")
    return result


def region_order_values() -> tuple[str, ...]:
    return tuple(REGION_ORDER_LABELS.values())


def _sign_extend(value: int, bits: int) -> int:
    sign = 1 << (bits - 1)
    mask = (1 << bits) - 1
    value &= mask
    return (value ^ sign) - sign


def _encode_signed(value: int, bits: int) -> int:
    return int(value) & ((1 << bits) - 1)


def normalize_region_suffix(value: str) -> str:
    text = re.sub(r"[^0-9A-Fa-f]", "", str(value)).upper()
    if len(text) != 8:
        raise ValueError(
            "Region suffix must be Y(2)+Z(3)+X(3), exactly eight hexadecimal characters."
        )
    int(text, 16)
    return text


def decode_region_suffix(value: str, *, require_canonical: bool = True) -> dict[str, Any]:
    text = normalize_region_suffix(value)
    y_raw = int(text[0:2], 16)
    z_raw = int(text[2:5], 16)
    x_raw = int(text[5:8], 16)
    y = _sign_extend(y_raw, 8)
    z = _sign_extend(z_raw, 12)
    x = _sign_extend(x_raw, 12)

    canonical = (
        Y_MIN <= y <= Y_MAX
        and Z_MIN <= z <= Z_MAX
        and X_MIN <= x <= X_MAX
    )
    if require_canonical and not canonical:
        details = []
        if y < Y_MIN or y > Y_MAX:
            details.append(f"Y={y} raw=0x{y_raw:02X}")
        if z < Z_MIN or z > Z_MAX:
            details.append(f"Z={z} raw=0x{z_raw:03X}")
        if x < X_MIN or x > X_MAX:
            details.append(f"X={x} raw=0x{x_raw:03X}")
        raise ValueError(
            "Region suffix contains a non-canonical coordinate that the game "
            "would normalize: " + ", ".join(details)
        )

    return {
        "region_suffix": text,
        "y_raw": y_raw,
        "z_raw": z_raw,
        "x_raw": x_raw,
        "y": y,
        "z": z,
        "x": x,
        "canonical": canonical,
    }


def encode_region_suffix(y: int, z: int, x: int) -> str:
    y = int(y)
    z = int(z)
    x = int(x)
    if not Y_MIN <= y <= Y_MAX:
        raise ValueError(f"Y region coordinate must be between {Y_MIN} and {Y_MAX}.")
    if not Z_MIN <= z <= Z_MAX:
        raise ValueError(f"Z region coordinate must be between {Z_MIN} and {Z_MAX}.")
    if not X_MIN <= x <= X_MAX:
        raise ValueError(f"X region coordinate must be between {X_MIN} and {X_MAX}.")
    return (
        f"{_encode_signed(y, 8):02X}"
        f"{_encode_signed(z, 12):03X}"
        f"{_encode_signed(x, 12):03X}"
    )


def region_ordinal(value: str) -> int:
    decoded = decode_region_suffix(value, require_canonical=True)
    y_index = int(decoded["y"]) - Y_MIN
    z_index = int(decoded["z"]) - Z_MIN
    x_index = int(decoded["x"]) - X_MIN
    return ((y_index * Z_COUNT) + z_index) * X_COUNT + x_index


def region_suffix_from_ordinal(value: int) -> str:
    ordinal = int(value)
    if not 0 <= ordinal < TOTAL_REGIONS_PER_GALAXY:
        raise ValueError(
            "Region ordinal must be between 0 and "
            f"{TOTAL_REGIONS_PER_GALAXY - 1}."
        )
    x_index = ordinal % X_COUNT
    remainder = ordinal // X_COUNT
    z_index = remainder % Z_COUNT
    y_index = remainder // Z_COUNT
    return encode_region_suffix(
        Y_MIN + y_index,
        Z_MIN + z_index,
        X_MIN + x_index,
    )


def region_suffix_at_offset(anchor_suffix: str, offset: int) -> str:
    start = region_ordinal(anchor_suffix)
    target = (start + int(offset)) % TOTAL_REGIONS_PER_GALAXY
    return region_suffix_from_ordinal(target)


def validate_region_window(region_offset: int, region_count: int) -> tuple[int, int]:
    offset = int(region_offset)
    count = int(region_count)
    if not 0 <= offset < TOTAL_REGIONS_PER_GALAXY:
        raise ValueError(
            "Region offset must be between 0 and "
            f"{TOTAL_REGIONS_PER_GALAXY - 1}."
        )
    if not 1 <= count <= TOTAL_REGIONS_PER_GALAXY:
        raise ValueError(
            "Regions to scan must be between 1 and "
            f"{TOTAL_REGIONS_PER_GALAXY}."
        )
    return offset, count


def iter_region_suffixes(
    anchor_suffix: str,
    *,
    region_offset: int = 0,
    region_count: int = 1,
) -> Iterator[dict[str, Any]]:
    canonical = normalize_region_suffix(anchor_suffix)
    decode_region_suffix(canonical, require_canonical=True)
    offset, count = validate_region_window(region_offset, region_count)
    start_ordinal = region_ordinal(canonical)
    for sequence_index in range(count):
        absolute_offset = offset + sequence_index
        target_ordinal = (
            start_ordinal + absolute_offset
        ) % TOTAL_REGIONS_PER_GALAXY
        suffix = region_suffix_from_ordinal(target_ordinal)
        decoded = decode_region_suffix(suffix, require_canonical=True)
        yield {
            "sequence_index": sequence_index,
            "sequence_number": sequence_index + 1,
            "region_offset": absolute_offset,
            "wrapped_offset": absolute_offset % TOTAL_REGIONS_PER_GALAXY,
            "ordinal": target_ordinal,
            "region_suffix": suffix,
            "y": decoded["y"],
            "z": decoded["z"],
            "x": decoded["x"],
        }



def iter_region_suffixes_nearest(
    anchor_suffix: str,
    *,
    region_offset: int = 0,
    region_count: int = 1,
) -> Iterator[dict[str, Any]]:
    """Yield canonical regions by exact squared 3D distance from the anchor.

    The finite nearest-first mode is intended for practical local searches.
    It does not wrap opposite galaxy boundaries together.
    """
    canonical = normalize_region_suffix(anchor_suffix)
    anchor = decode_region_suffix(canonical, require_canonical=True)
    offset, count = validate_region_window(region_offset, region_count)
    needed = offset + count
    if needed > NEAREST_REGION_LIMIT:
        raise ValueError(
            f"Nearest-first traversal supports at most {NEAREST_REGION_LIMIT:,} "
            "regions including the skipped offset. Use sequential order for larger scans."
        )

    ay, az, ax = int(anchor["y"]), int(anchor["z"]), int(anchor["x"])
    radius = 0
    candidates: list[tuple[int, int, int, int]] = []
    while True:
        radius += 1
        candidates = []
        for dy in range(-radius, radius + 1):
            y = ay + dy
            if y < Y_MIN or y > Y_MAX:
                continue
            for dz in range(-radius, radius + 1):
                z = az + dz
                if z < Z_MIN or z > Z_MAX:
                    continue
                for dx in range(-radius, radius + 1):
                    x = ax + dx
                    if x < X_MIN or x > X_MAX:
                        continue
                    dist2 = dx * dx + dz * dz + dy * dy
                    candidates.append((dist2, dy, dz, dx))
        candidates.sort(
            key=lambda item: (
                item[0],
                abs(item[1]) + abs(item[2]) + abs(item[3]),
                item[1], item[2], item[3],
            )
        )
        if len(candidates) >= needed:
            nth_distance = candidates[needed - 1][0]
            # Any point outside this cube has at least one coordinate radius+1.
            if nth_distance < (radius + 1) * (radius + 1):
                break

    selected = candidates[offset:needed]
    for sequence_index, (dist2, dy, dz, dx) in enumerate(selected):
        y, z, x = ay + dy, az + dz, ax + dx
        suffix = encode_region_suffix(y, z, x)
        yield {
            "sequence_index": sequence_index,
            "sequence_number": sequence_index + 1,
            "region_offset": offset + sequence_index,
            "wrapped_offset": None,
            "ordinal": region_ordinal(suffix),
            "region_suffix": suffix,
            "y": y, "z": z, "x": x,
            "delta_y": dy, "delta_z": dz, "delta_x": dx,
            "distance_squared": dist2,
            "region_order": REGION_ORDER_NEAREST,
        }


def iter_region_suffixes_ordered(
    anchor_suffix: str,
    *,
    region_offset: int = 0,
    region_count: int = 1,
    region_order: str = REGION_ORDER_SEQUENTIAL,
) -> Iterator[dict[str, Any]]:
    order = normalize_region_order(region_order)
    if order == REGION_ORDER_NEAREST:
        yield from iter_region_suffixes_nearest(
            anchor_suffix, region_offset=region_offset, region_count=region_count
        )
        return
    for row in iter_region_suffixes(
        anchor_suffix, region_offset=region_offset, region_count=region_count
    ):
        row = dict(row)
        row["region_order"] = REGION_ORDER_SEQUENTIAL
        yield row


def space_metadata(anchor_suffix: str | None = None) -> dict[str, Any]:
    anchor = None
    if anchor_suffix is not None:
        decoded = decode_region_suffix(anchor_suffix, require_canonical=True)
        anchor = {
            **decoded,
            "ordinal": region_ordinal(decoded["region_suffix"]),
        }
    return {
        "version": VERSION,
        "coordinate_order": "X then Z then Y",
        "available_region_orders": REGION_ORDER_LABELS,
        "nearest_region_limit": NEAREST_REGION_LIMIT,
        "wraps_after_full_space": True,
        "x_min": X_MIN,
        "x_max": X_MAX,
        "x_count": X_COUNT,
        "z_min": Z_MIN,
        "z_max": Z_MAX,
        "z_count": Z_COUNT,
        "y_min": Y_MIN,
        "y_max": Y_MAX,
        "y_count": Y_COUNT,
        "total_regions_per_galaxy": TOTAL_REGIONS_PER_GALAXY,
        "purple_systems_per_region": PURPLE_SYSTEMS_PER_REGION,
        "total_purple_systems_per_galaxy": TOTAL_PURPLE_SYSTEMS_PER_GALAXY,
        "maximum_legacy_candidate_systems_per_region": (
            MAX_LEGACY_CANDIDATE_SYSTEMS_PER_REGION
        ),
        "maximum_legacy_candidate_systems_per_galaxy": (
            MAX_LEGACY_CANDIDATE_SYSTEMS_PER_GALAXY
        ),
        "anchor": anchor,
    }


def run_self_test() -> dict[str, Any]:
    samples = (
        (Y_MIN, Z_MIN, X_MIN),
        (-109, -158, -170),
        (0, 0, 0),
        (Y_MAX, Z_MAX, X_MAX),
    )
    roundtrips = []
    for y, z, x in samples:
        suffix = encode_region_suffix(y, z, x)
        decoded = decode_region_suffix(suffix)
        ordinal = region_ordinal(suffix)
        rebuilt = region_suffix_from_ordinal(ordinal)
        exact = (
            decoded["y"] == y
            and decoded["z"] == z
            and decoded["x"] == x
            and rebuilt == suffix
        )
        roundtrips.append({
            "input": {"y": y, "z": z, "x": x},
            "suffix": suffix,
            "ordinal": ordinal,
            "rebuilt": rebuilt,
            "exact": exact,
        })

    boundary_anchor = encode_region_suffix(Y_MAX, Z_MAX, X_MAX)
    wrapped = region_suffix_at_offset(boundary_anchor, 1)
    expected_wrap = encode_region_suffix(Y_MIN, Z_MIN, X_MIN)
    first_three = list(iter_region_suffixes(
        encode_region_suffix(0, 0, 0),
        region_offset=0,
        region_count=3,
    ))
    unique_first_three = len({row["region_suffix"] for row in first_three}) == 3
    checks = {
        "counts": (
            X_COUNT == 4095
            and Z_COUNT == 4095
            and Y_COUNT == 255
            and TOTAL_REGIONS_PER_GALAXY == 4_276_101_375
        ),
        "roundtrips": all(row["exact"] for row in roundtrips),
        "full_space_wrap": wrapped == expected_wrap,
        "first_three_unique": unique_first_three,
        "purple_total": (
            TOTAL_PURPLE_SYSTEMS_PER_GALAXY == 273_670_488_000
        ),
        "legacy_candidate_max_total": (
            MAX_LEGACY_CANDIDATE_SYSTEMS_PER_GALAXY
            == 3_284_045_856_000
        ),
    }
    return {
        "version": VERSION,
        "exact": all(checks.values()),
        "checks": checks,
        "roundtrips": roundtrips,
        "boundary_wrap": {
            "anchor": boundary_anchor,
            "observed": wrapped,
            "expected": expected_wrap,
        },
        "first_three": first_three,
        "space": space_metadata(),
    }


if __name__ == "__main__":
    import json
    result = run_self_test()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["exact"] else 1)

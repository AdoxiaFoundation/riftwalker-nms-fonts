#!/usr/bin/env python3
"""Portable exact current-build NMS procedural Markov-name generator.

This is a clean implementation. It does not execute or include NMS machine
code. The accompanying data file contains the eight extracted current-build
Markov datasets.
"""
from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path
from typing import Any, Sequence

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
UNIT_U32 = 1.0 / 4294967296.0
VOWELS = frozenset('aeiou')
VOWELS_AND_Y = frozenset('aeiouy')

DATA_PATH = Path(__file__).resolve().with_name(
    'namegen_markov_datasets_8_exact.json'
)
_RAW_DATA = json.loads(DATA_PATH.read_text(encoding='utf-8'))['datasets']
DATASETS: dict[int, dict[str, Any]] = {
    int(index): value for index, value in _RAW_DATA.items()
}


def f32(value: float) -> float:
    return struct.unpack('<f', struct.pack('<f', float(value)))[0]


def high_multiply_u32(word: int, count: int) -> int:
    return ((word & MASK32) * int(count)) >> 32


class MWC:
    """NMS multiply-with-carry state."""

    __slots__ = ('value', 'carry')

    def __init__(self, seed: int) -> None:
        seed &= MASK64
        low = seed & MASK32
        high = (seed >> 32) & MASK32
        if low == 0:
            low = 1
        rotated = ((low >> 16) | ((low << 16) & MASK32)) & MASK32
        self.value = low
        self.carry = (rotated ^ high ^ low) & MASK32

    @classmethod
    def from_state(cls, value: int, carry: int) -> 'MWC':
        instance = cls.__new__(cls)
        instance.value = value & MASK32
        instance.carry = carry & MASK32
        return instance

    def draw(self) -> int:
        total = MWC_MULTIPLIER * self.value + self.carry
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        return self.value

    def state_dict(self) -> dict[str, Any]:
        return {
            'value': self.value,
            'carry': self.carry,
            'value_hex': f'0x{self.value:08X}',
            'carry_hex': f'0x{self.carry:08X}',
        }


# Exact first-character dispatch and branch order from the native cleanup
# routine. Every rewrite consumes exactly one MWC draw.
CLEANUP_RULES: dict[str, tuple[int, str]] = {
    'ass': (0, 'eo'),
    'anus': (1, 'tdwzx'),
    'anal': (1, 'tdwzx'),
    'boner': (0, 'lvsz'),
    'blow': (0, 'caog'),
    'bitch': (3, 'ao'),
    'cunt': (1, 'eio'),
    'cum': (0, 'rgsn'),
    'cuck': (3, 'aeiou'),
    'cock': (0, 'smlth'),
    'clit': (3, 'cpfn'),
    'dong': (3, 'teo'),
    'dick': (2, 'aeol'),
    'homo': (1, 'eiu'),
    'hitler': (0, 'vmpl'),
    'fuck': (0, 'zlbw'),
    'felch': (0, 'njkmp'),
    'fag': (0, 'nmtz'),
    'gook': (3, 'lnrb'),
    'jizz': (0, 'zrwl'),
    'kunt': (3, 'aeo'),
    'kike': (2, 'rbl'),
    'love': (2, 'mpbt'),
    'mong': (3, 'aoik'),
    'minge': (3, 'amlz'),
    'nig': (0, 'rvxb'),
    'negr': (0, 'rvlt'),
    'nazi': (0, 'ryvn'),
    'orgy': (2, 'vlos'),
    'paedo': (0, 'tmvs'),
    'paki': (2, 'ntr'),
    'penis': (0, 'klsr'),
    'pedo': (0, 'tmvs'),
    'piss': (2, 'cokl'),
    'prick': (0, 'stbc'),
    'porn': (0, 'tvbr'),
    'puss': (0, 'brsl'),
    'quee': (2, 'nlr'),
    'rape': (2, 'cnys'),
    'spunk': (1, 'lh'),
    'spic': (3, 'nlr'),
    'spaz': (3, 'nlr'),
    'slut': (2, 'aeo'),
    'slag': (3, 'dnvy'),
    'shit': (3, 'nvsl'),
    'shag': (3, 'nml'),
    'sex': (0, 'tdrp'),
    'semen': (2, 'tzrv'),
    'twat': (1, 'ehi'),
    'turd': (3, 'nbtp'),
    'tit': (2, 'nmbc'),
    'tard': (0, 'jcgwz'),
    'wop': (0, 'csld'),
    'wog': (0, 'cslv'),
    'whore': (0, 'csa'),
    'wank': (3, 'aei'),
}

CLEANUP_ORDER: dict[str, tuple[str, ...]] = {
    'a': ('ass', 'anus', 'anal'),
    'b': ('boner', 'blow', 'bitch'),
    'c': ('clit', 'cock', 'cunt', 'cuck', 'cum'),
    'd': ('dong', 'dick'),
    'h': ('homo', 'hitler'),
    'f': ('fuck', 'felch', 'fag'),
    'g': ('gook',),
    'j': ('jizz',),
    'k': ('kunt', 'kike'),
    'l': ('love',),
    'm': ('mong', 'minge'),
    'n': ('nig', 'negr', 'nazi'),
    'o': ('orgy',),
    'p': ('paedo', 'paki', 'penis', 'pedo', 'piss', 'prick', 'porn', 'puss'),
    'q': ('quee',),
    'r': ('rape',),
    's': ('spunk', 'spic', 'spaz', 'slut', 'slag', 'shit', 'shag', 'sex', 'semen'),
    't': ('twat', 'turd', 'tit', 'tard'),
    'w': ('wop', 'wog', 'whore', 'wank'),
}


def cleanup_at_index(state: MWC, text: str, index: int) -> tuple[bool, str]:
    if index < 0 or index >= len(text):
        return False, text
    for pattern in CLEANUP_ORDER.get(text[index], ()):
        if text.startswith(pattern, index):
            replacement_offset, replacements = CLEANUP_RULES[pattern]
            replacement = replacements[
                high_multiply_u32(state.draw(), len(replacements))
            ]
            target = index + replacement_offset
            return True, text[:target] + replacement + text[target + 1:]
    return False, text


def cleanup_all(state: MWC, text: str) -> str:
    # Rewrites preserve string length, so the native fixed-length scan is exact.
    original_length = len(text)
    for index in range(original_length):
        _, text = cleanup_at_index(state, text, index)
    return text


def _select_transition(
    entry: dict[str, Any],
    probability: float,
    mode: str,
) -> str:
    chars: Sequence[str] = entry['chars']
    weights: Sequence[float] = entry['weights']
    if len(chars) == 1:
        return chars[0]
    if mode == 'weighted':
        cumulative = f32(0.0)
        for char, weight in zip(chars, weights):
            cumulative = f32(cumulative + f32(weight))
            if cumulative >= probability:
                return char
        return chars[-1]
    index = int(
        f32(
            f32(probability * f32(len(chars) - 1))
            + f32(0.5)
        )
    )
    index = max(0, min(index, len(chars) - 1))
    return chars[index]


def _start_cluster_invalid(first: str, second: str) -> bool:
    if first in VOWELS or second in VOWELS:
        return False
    if first == 's' and second in 'hklmnprtwy':
        return False
    if second == 'h' and first in 'ctw':
        return False
    if second == 'l' and first in 'bcfgps':
        return False
    if second == 'r' and first in 'bcdfgikpt':
        return False
    if second == 'w' and first in 'dgt':
        return False
    if second == 'y' and first in 'hmr':
        return False
    return True


def _end_cluster_invalid(previous: str, final: str) -> bool:
    if previous == 'g':
        return False
    if final == 'b':
        return previous in 'gn'
    if final == 'd':
        return previous in 'bdfghkmpst'
    if final == 'g':
        return previous == 'l'
    if final == 'p':
        return previous in 'bdhkt'
    if final == 'r':
        return previous in 'bfg'
    if final == 't':
        return previous == 'g'
    if final == 'w':
        return previous not in VOWELS
    return False


def _first_four_consonants(text: str) -> int:
    count = 0
    for index, char in enumerate(text):
        if count == 3:
            if char in VOWELS_AND_Y:
                count = 0
            else:
                return index - 3
        if char in VOWELS:
            count = 0
        else:
            count += 1
    return -1


def generate_markov(
    state: MWC,
    dataset_index: int,
    minimum_length: int,
    maximum_length: int,
    *,
    details: bool = False,
) -> str | tuple[str, dict[str, Any]]:
    if dataset_index not in DATASETS:
        raise ValueError(f'Invalid dataset index: {dataset_index}')
    if minimum_length < 3 or maximum_length < minimum_length:
        raise ValueError('Lengths must satisfy 3 <= minimum <= maximum.')

    original_dataset = DATASETS[dataset_index]
    initial_word = state.draw()
    initial = original_dataset['initial_trigrams'][
        high_multiply_u32(
            initial_word,
            len(original_dataset['initial_trigrams']),
        )
    ]
    mode_word = state.draw()
    mode = 'uniform' if mode_word & 1 else 'weighted'
    target_word = state.draw()
    target_length = minimum_length + high_multiply_u32(
        target_word,
        maximum_length - minimum_length + 1,
    )

    output = initial
    remaining = target_length - 3
    current_dataset_index = dataset_index
    retry_count = 8
    fallback_count = 0

    while remaining > 0 and len(output) < 63:
        context = output[-3:]
        probability_word = state.draw()
        probability = f32(probability_word * UNIT_U32)
        entry = DATASETS[current_dataset_index]['transitions'].get(context)
        next_char = (
            _select_transition(entry, probability, mode)
            if entry is not None
            else None
        )
        if next_char and next_char != '\xff':
            output += next_char
            remaining -= 1
            continue

        current_dataset_index = (current_dataset_index + 1) % 8
        retry_count -= 1
        if retry_count > 0:
            continue

        # The native routine does not append a fallback trigram when fewer
        # than three logical target characters remain.
        if remaining < 3:
            break

        fallback_word = state.draw()
        fallback = original_dataset['initial_trigrams'][
            high_multiply_u32(
                fallback_word,
                len(original_dataset['initial_trigrams']),
            )
        ]
        consumed = (target_length - 3) - remaining
        bridge_previous = output[2 + consumed]
        bridge_next = fallback[0]
        if bridge_previous in VOWELS and bridge_next in VOWELS:
            output += "'"
        elif bridge_previous not in VOWELS and bridge_next not in VOWELS:
            output += 'aeiou'[high_multiply_u32(state.draw(), 5)]
        output += fallback
        remaining -= 3
        retry_count = 1
        fallback_count += 1

    if len(output) >= 2 and _start_cluster_invalid(output[0], output[1]):
        output = (
            output[0]
            + 'aeiou'[high_multiply_u32(state.draw(), 5)]
            + output[1:]
        )

    if len(output) >= 2 and _end_cluster_invalid(output[-2], output[-1]):
        output = (
            output[:-1]
            + 'aeiou'[high_multiply_u32(state.draw(), 5)]
            + output[-1]
        )

    cluster_start = _first_four_consonants(output)
    if cluster_start != -1:
        insertion_position = (
            cluster_start + 1 + high_multiply_u32(state.draw(), 3)
        )
        vowel = 'aeiou'[high_multiply_u32(state.draw(), 5)]
        output = (
            output[:insertion_position]
            + vowel
            + output[insertion_position:]
        )

    output = cleanup_all(state, output)

    if not details:
        return output
    return output, {
        'dataset_index': dataset_index,
        'minimum_length': minimum_length,
        'maximum_length': maximum_length,
        'initial_trigram': initial,
        'selection_mode': mode,
        'target_length': target_length,
        'fallback_count': fallback_count,
        'final_state': state.state_dict(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('seed', help='64-bit seed in decimal or 0x form')
    parser.add_argument('dataset', type=int)
    parser.add_argument('minimum', type=int)
    parser.add_argument('maximum', type=int)
    parser.add_argument('--predraws', type=int, default=0)
    args = parser.parse_args()

    state = MWC(int(args.seed, 0))
    for _ in range(args.predraws):
        state.draw()
    name, details = generate_markov(
        state,
        args.dataset,
        args.minimum,
        args.maximum,
        details=True,
    )
    print(json.dumps({'name': name, **details}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

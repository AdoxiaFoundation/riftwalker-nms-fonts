#!/usr/bin/env python3
"""App-owned simplex-noise primitives for APF V20G1.

This module is a clean-room implementation of the standard 3D simplex-noise
algorithm with analytic derivatives. It contains no NMS executable bytes,
module image, process-memory reader, native address, or game-specific table.
The permutation is the canonical public Ken Perlin permutation used by the
standard improved/simplex-noise reference algorithm.
"""
from __future__ import annotations

import math
import struct
from typing import Final

VERSION: Final[str] = "20G1.0.0"

# Canonical public Ken Perlin permutation, duplicated for wrap-free lookup.
_PERMUTATION: Final[tuple[int, ...]] = (
    151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,
    140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,
    247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,
    57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,
    74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,
    60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,
    65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,
    200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,
    52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,
    207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,
    119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,
    129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,
    218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,
    81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,
    184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,
    222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180,
)
_PERM: Final[tuple[int, ...]] = _PERMUTATION + _PERMUTATION

# Standard 16-entry padded 3D gradient set selected by hash & 15.
_GRAD3: Final[tuple[tuple[float, float, float], ...]] = (
    ( 1.0, 0.0, 1.0), ( 0.0, 1.0, 1.0), (-1.0, 0.0, 1.0), ( 0.0,-1.0, 1.0),
    ( 1.0, 0.0,-1.0), ( 0.0, 1.0,-1.0), (-1.0, 0.0,-1.0), ( 0.0,-1.0,-1.0),
    ( 1.0,-1.0, 0.0), ( 1.0, 1.0, 0.0), (-1.0, 1.0, 0.0), (-1.0,-1.0, 0.0),
    ( 1.0, 0.0, 1.0), (-1.0, 0.0, 1.0), ( 0.0, 1.0,-1.0), ( 0.0,-1.0,-1.0),
)

_F3: Final[float] = struct.unpack('<f', struct.pack('<f', 1.0 / 3.0))[0]
_G3: Final[float] = struct.unpack('<f', struct.pack('<f', 1.0 / 6.0))[0]
_ATTENUATION: Final[float] = struct.unpack('<f', struct.pack('<f', 0.6))[0]
_NOISE_SCALE: Final[float] = 28.0
_DERIVATIVE_FACTOR: Final[float] = -8.0


def f32(value: float) -> float:
    """Round one value exactly to IEEE-754 binary32."""
    return struct.unpack('<f', struct.pack('<f', float(value)))[0]


def _add(a: float, b: float) -> float:
    return f32(f32(a) + f32(b))


def _sub(a: float, b: float) -> float:
    return f32(f32(a) - f32(b))


def _mul(a: float, b: float) -> float:
    return f32(f32(a) * f32(b))


def _corner(
    gradient: tuple[float, float, float],
    x: float,
    y: float,
    z: float,
) -> tuple[float, float, float, float]:
    x = f32(x); y = f32(y); z = f32(z)
    radius = _sub(_ATTENUATION, _add(_add(_mul(x, x), _mul(y, y)), _mul(z, z)))
    if radius <= 0.0:
        return 0.0, 0.0, 0.0, 0.0

    gx, gy, gz = gradient
    dot = _add(_add(_mul(gx, x), _mul(gy, y)), _mul(gz, z))
    radius2 = _mul(radius, radius)
    radius3 = _mul(radius2, radius)
    radius4 = _mul(radius2, radius2)
    contribution = _mul(radius4, dot)

    common = _mul(_mul(_DERIVATIVE_FACTOR, radius3), dot)
    dx = _add(_mul(common, x), _mul(radius4, gx))
    dy = _add(_mul(common, y), _mul(radius4, gy))
    dz = _add(_mul(common, z), _mul(radius4, gz))
    return contribution, dx, dy, dz


def simplex3_with_derivative(x: float, y: float, z: float) -> tuple[float, float, float, float]:
    """Return standard 3D simplex noise and analytic x/y/z derivatives."""
    x = f32(x); y = f32(y); z = f32(z)
    skew = _mul(_add(_add(x, y), z), _F3)
    i = math.floor(_add(x, skew))
    j = math.floor(_add(y, skew))
    k = math.floor(_add(z, skew))

    unskew = _mul(float(i + j + k), _G3)
    x0 = _sub(x, _sub(float(i), unskew))
    y0 = _sub(y, _sub(float(j), unskew))
    z0 = _sub(z, _sub(float(k), unskew))

    if x0 >= y0:
        if y0 >= z0:
            i1, j1, k1 = 1, 0, 0
            i2, j2, k2 = 1, 1, 0
        elif x0 >= z0:
            i1, j1, k1 = 1, 0, 0
            i2, j2, k2 = 1, 0, 1
        else:
            i1, j1, k1 = 0, 0, 1
            i2, j2, k2 = 1, 0, 1
    else:
        if y0 < z0:
            i1, j1, k1 = 0, 0, 1
            i2, j2, k2 = 0, 1, 1
        elif x0 < z0:
            i1, j1, k1 = 0, 1, 0
            i2, j2, k2 = 0, 1, 1
        else:
            i1, j1, k1 = 0, 1, 0
            i2, j2, k2 = 1, 1, 0

    x1 = _add(_sub(x0, float(i1)), _G3)
    y1 = _add(_sub(y0, float(j1)), _G3)
    z1 = _add(_sub(z0, float(k1)), _G3)
    x2 = _add(_sub(x0, float(i2)), _mul(2.0, _G3))
    y2 = _add(_sub(y0, float(j2)), _mul(2.0, _G3))
    z2 = _add(_sub(z0, float(k2)), _mul(2.0, _G3))
    x3 = _add(_sub(x0, 1.0), _mul(3.0, _G3))
    y3 = _add(_sub(y0, 1.0), _mul(3.0, _G3))
    z3 = _add(_sub(z0, 1.0), _mul(3.0, _G3))

    ii = i & 255; jj = j & 255; kk = k & 255
    g0 = _GRAD3[_PERM[ii + _PERM[jj + _PERM[kk]]] & 15]
    g1 = _GRAD3[_PERM[ii + i1 + _PERM[jj + j1 + _PERM[kk + k1]]] & 15]
    g2 = _GRAD3[_PERM[ii + i2 + _PERM[jj + j2 + _PERM[kk + k2]]] & 15]
    g3 = _GRAD3[_PERM[ii + 1 + _PERM[jj + 1 + _PERM[kk + 1]]] & 15]

    corners = (
        _corner(g0, x0, y0, z0),
        _corner(g1, x1, y1, z1),
        _corner(g2, x2, y2, z2),
        _corner(g3, x3, y3, z3),
    )
    noise = dx = dy = dz = 0.0
    for n, cx, cy, cz in corners:
        noise = _add(noise, n)
        dx = _add(dx, cx)
        dy = _add(dy, cy)
        dz = _add(dz, cz)
    return (
        _mul(noise, _NOISE_SCALE),
        _mul(dx, _NOISE_SCALE),
        _mul(dy, _NOISE_SCALE),
        _mul(dz, _NOISE_SCALE),
    )


def normalized_fractal_noise3(
    x: float,
    y: float,
    z: float,
    octaves: int = 4,
    lacunarity: float = 1.25,
    gain: float = 0.9,
) -> float:
    """Reproduce the generator's derivative-normalized multi-octave noise."""
    frequency = f32(1.0)
    amplitude = f32(1.0)
    total = f32(0.5)
    lacunarity = f32(lacunarity)
    gain = f32(gain)
    cumulative_dx = f32(0.0)
    cumulative_dy = f32(0.0)
    cumulative_dz = f32(0.0)

    for _ in range(max(0, int(octaves))):
        noise, dx, dy, dz = simplex3_with_derivative(
            _mul(x, frequency), _mul(y, frequency), _mul(z, frequency)
        )
        # Native V20E occupancy helper accumulates the analytic gradient across
        # octaves before applying the derivative-normalisation denominator.
        # It does not normalise each octave independently.
        cumulative_dx = _add(cumulative_dx, dx)
        cumulative_dy = _add(cumulative_dy, dy)
        cumulative_dz = _add(cumulative_dz, dz)
        gradient_sq = _add(
            _add(_mul(cumulative_dx, cumulative_dx), _mul(cumulative_dy, cumulative_dy)),
            _mul(cumulative_dz, cumulative_dz),
        )
        denominator = _add(gradient_sq, 1.0)
        weighted = f32(_mul(noise, amplitude) / denominator)
        total = _add(total, weighted)
        frequency = _mul(frequency, lacunarity)
        amplitude = _mul(amplitude, gain)
    return total


__all__ = ['VERSION', 'f32', 'simplex3_with_derivative', 'normalized_fractal_noise3']

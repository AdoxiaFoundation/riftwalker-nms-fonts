#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import address_only_water_profile_rng_v1 as profile_rng
import address_only_water_style_v1 as style_rng

ROOT = Path(__file__).resolve().parent
MATRIX = json.loads(
    (ROOT / "water_emission_matrix_current_build.json").read_text(
        encoding="utf-8"
    )
)["records"]
STYLES = json.loads(
    (ROOT / "water_style_records_current_build.json").read_text(
        encoding="utf-8"
    )
)["records"]

def matrix_lookup(
    biome: int,
    subtype: int,
) -> tuple[dict[str, Any], str]:
    rows = {
        (int(row["biome"]), int(row["subtype"])): row
        for row in MATRIX
    }
    direct = rows.get((biome, subtype))
    if direct and direct["override_default"]:
        return direct, "exact_override"
    biome_default = rows.get((biome, 0))
    if biome_default and biome_default["override_default"]:
        return biome_default, "biome_default_override"
    return rows[(16, 0)], "global_default_16_0"

def predict(root_seed: int, biome: int, subtype: int) -> dict[str, Any]:
    style_result = style_rng.predict_from_root_seed(root_seed)
    rng_result = profile_rng.predict_from_root_seed(root_seed)
    matrix_row, matrix_source = matrix_lookup(biome, subtype)

    water = profile_rng.select_weighted_enum(
        rng_result["water_emission_selector_word"],
        matrix_row["water_weights"],
    )
    foam = profile_rng.select_weighted_enum(
        rng_result["foam_emission_selector_word"],
        matrix_row["foam_weights"],
    )
    style = STYLES[int(style_result["style_index"])]
    intrinsic = style["FoamEmission"]

    return {
        "status": "PASS_ADDRESS_ONLY_WATER_PROFILE_V2",
        "root_seed_hex": f"0x{root_seed & 0xFFFFFFFFFFFFFFFF:016X}",
        "biome": biome,
        "subtype": subtype,
        "style": {
            "index": style["index"],
            "family": style["style_family"],
            "selection_weighting": style["selection_weighting"],
            "foam_colour": style["FoamColour"],
            "intrinsic_foam_emission": intrinsic,
        },
        "murkyness": {
            "value_f32": rng_result["murkyness_f32"],
            "bits_hex": rng_result["murkyness_bits_hex"],
        },
        "matrix": {
            "source": matrix_source,
            "record_biome": matrix_row["biome"],
            "record_subtype": matrix_row["subtype"],
        },
        "WaterEmission": {
            **water,
            "active": water["enum"] != 0,
        },
        "FoamEmission": {
            **foam,
            "active": foam["enum"] != 0,
            "timing": foam["enum_name"],
            "intrinsic_hdr_rgba": intrinsic["rgba_f32"],
            "normalised_hue_preview_hex": intrinsic[
                "normalised_hue_hex"
            ],
        },
        "rendering_boundary": {
            "generated_profile_exact": True,
            "final_screenshot_pixels_not_claimed": (
                "Atmosphere, lighting, depth, exposure, filters and "
                "post-processing alter the rendered result."
            ),
        },
    }

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root_seed", help="64-bit root seed, decimal or 0x...")
    parser.add_argument("biome", type=int)
    parser.add_argument("subtype", type=int)
    args = parser.parse_args()
    print(json.dumps(
        predict(int(args.root_seed, 0), args.biome, args.subtype),
        indent=2,
    ))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

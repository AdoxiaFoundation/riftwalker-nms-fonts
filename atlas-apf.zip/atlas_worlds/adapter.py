"""Observatory adapter for ATLAS APF v1.0.61 full planet dossier data.

ATLAS APF / FIBONACCI is the source for the deterministic planet-generation
replay used here. Observatory extracts a deliberately compact, player-facing
subset of ATLAS's much larger per-world record.
"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
APF = HERE / "apf"
CORE_PATH = APF / "any_planet_finder_core.py"
_core = None


def _load_core():
    global _core
    if _core is not None:
        return _core
    if not CORE_PATH.is_file():
        raise FileNotFoundError(f"ATLAS APF core not found: {CORE_PATH}")
    if str(APF) not in sys.path:
        sys.path.insert(0, str(APF))
    spec = importlib.util.spec_from_file_location("observatory_atlas_apf_core_v1061", CORE_PATH)
    if spec is None or spec.loader is None:
        raise ImportError(CORE_PATH)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _core = module
    return module


def _norm_portal(portal: str) -> str:
    p = "".join(c for c in str(portal).upper() if c in "0123456789ABCDEF")
    if len(p) != 12:
        raise ValueError("Portal address must contain exactly 12 hexadecimal digits.")
    return p


def _resource(core, internal_id: Any) -> dict[str, Any] | None:
    if not internal_id:
        return None
    ident = str(internal_id)
    try:
        name = core.substance_localized_name(ident)
    except Exception:
        name = ident
    return {"name": name, "id": ident}


def _simple(v: Any):
    return v if isinstance(v, (str, int, float, bool)) or v is None else None


def _world_record(core, row: dict[str, Any]) -> dict[str, Any]:
    is_moon = bool(row.get("is_moon"))
    common = _resource(core, row.get("common_substance_id"))
    uncommon = _resource(core, row.get("uncommon_substance_id"))
    rare = _resource(core, row.get("rare_substance_id"))

    special_flags = []
    if row.get("infested_planet"):
        special_flags.append("Infested")
    if row.get("portal_safe_dissonant_planet"):
        special_flags.append("Dissonant / Corrupt Sentinels")
    if row.get("biome_variant_has_floating_islands"):
        special_flags.append("Floating-island biome source")
    if row.get("salvageable_scrap_available"):
        special_flags.append("Salvageable Scrap")
    if row.get("has_rings"):
        special_flags.append("Planetary rings")
    if row.get("bioluminescent_grass_carpet_available"):
        special_flags.append("Bioluminescent grass carpet")
    if row.get("glowing_mushroom_asset_available"):
        special_flags.append("Glowing mushroom assets")

    flora_assets = []
    if row.get("explicit_grass_asset_available"):
        flora_assets.append("Grass")
    if row.get("glowing_grass_asset_available"):
        flora_assets.append("Glowing grass")
    if row.get("mushroom_asset_available"):
        flora_assets.append("Mushrooms")
    if row.get("glowing_mushroom_asset_available"):
        flora_assets.append("Glowing mushroom trees")
    if row.get("glowing_ground_foliage_available"):
        flora_assets.append("Glowing ground foliage")

    atmosphere = {
        "day": row.get("day_atmosphere_display") or row.get("rendered_day_sky_display"),
        "sky": f"{row.get('atmosphere_sky_primary_family')} {row.get('atmosphere_sky_primary_hex')}" if row.get("atmosphere_sky_primary_hex") else None,
        "horizon": f"{row.get('atmosphere_horizon_primary_family')} {row.get('atmosphere_horizon_primary_hex')}" if row.get("atmosphere_horizon_primary_hex") else None,
        "sunset": f"{row.get('atmosphere_sunset_primary_family')} {row.get('atmosphere_sunset_primary_hex')}" if row.get("atmosphere_sunset_primary_hex") else None,
        "night": f"{row.get('atmosphere_night_primary_family')} {row.get('atmosphere_night_primary_hex')}" if row.get("atmosphere_night_primary_hex") else None,
        "fog": f"{row.get('atmosphere_fog_primary_family')} {row.get('atmosphere_fog_primary_hex')}" if row.get("atmosphere_fog_primary_hex") else None,
        "cloud": f"{row.get('atmosphere_cloud_primary_family')} {row.get('atmosphere_cloud_primary_hex')}" if row.get("atmosphere_cloud_primary_hex") else None,
    }

    return {
        "slot": int(row.get("gameplay_planet_number", int(row.get("slot", 0)) + 1)),
        "name": row.get("default_procedural_planet_name") or "Unavailable",
        "is_moon": is_moon,
        "parent_planet_number": row.get("moon_parent_gameplay_planet_number") if is_moon else None,
        "parent_name": row.get("moon_parent_default_procedural_name") if is_moon else None,
        "body_type": row.get("planet_body_type_display") or row.get("world_type_display") or ("Moon" if is_moon else "Planet"),
        "size": row.get("body_type_and_size_display") or row.get("native_planet_size_class_display") or row.get("world_size_display"),
        "classification": row.get("planet_classification_display"),
        "biome_code": row.get("effective_biome", row.get("biome")),
        "biome": row.get("effective_biome_name") or row.get("biome_name"),
        "biome_subtype_code": row.get("biome_subtype"),
        "biome_subtype": row.get("biome_variant_display") or row.get("biome_subtype_name") or row.get("biome_subtype_display"),
        "biome_subtype_display": row.get("biome_subtype_display"),
        "terrain": {
            "family": row.get("terrain_family_display"),
            "setting": row.get("terrain_setting_display"),
            "visual_note": row.get("terrain_visual_description"),
        },
        "weather": {
            "name": row.get("weather_display"),
            "functional": row.get("weather_functional_display"),
            "storm_frequency": row.get("weather_storm_frequency"),
            "severity": row.get("weather_severity_display"),
            "passive_hazard": row.get("weather_passive_hazard"),
            "source": row.get("weather_source_display"),
            "exact": bool(row.get("weather_display_exact")),
        },
        "sentinels": {
            "discovery": row.get("sentinel_discovery_display"),
            "functional_activity": row.get("sentinel_standard_activity_display"),
            "standard_activity": row.get("sentinel_standard_activity_display"),
            "reference_difficulty": row.get("sentinel_difficulty_reference_name"),
            "standard_difficulty": "Standard",
            "level": row.get("sentinel_level"),
            "dissonant": bool(row.get("portal_safe_dissonant_planet")),
            "exact": bool(row.get("sentinel_discovery_exact")),
        },
        "resources": {
            "display": row.get("resources_display"),
            "abundance": row.get("resource_abundance"),
            "common": common,
            "uncommon": uncommon,
            "rare": rare,
            "exact": bool(row.get("resources_display_exact")),
        },
        "fauna": {
            "display": row.get("fauna_display"),
            "abundance": row.get("fauna_abundance"),
            "life_level": row.get("creature_life_level"),
            "descriptor_profile": row.get("fauna_descriptor_profile_summary"),
            "community_signal": row.get("fauna_community_archetype_signal_summary"),
            "dangerous_predator_signal": bool(row.get("dangerous_predatory_fauna_signal_present")),
            "dangerous_signal_boundary": row.get("dangerous_predatory_fauna_signal_boundary"),
            "exact_abundance": bool(row.get("fauna_display_exact")),
        },
        "flora": {
            "display": row.get("flora_display"),
            "abundance": row.get("flora_abundance"),
            "assets": flora_assets,
            "grass_primary_hex": row.get("grass_primary_hex"),
            "grass_alt_primary_hex": row.get("grass_alt_primary_hex"),
            "exact_abundance": bool(row.get("flora_display_exact")),
        },
        "water": {
            "active": bool(row.get("water_active")),
            "sea_level": row.get("sea_level"),
            "profile": row.get("water_profile_display"),
            "generated_colour": row.get("generated_water_primary_colour_display"),
            "generated_colour_hex": row.get("generated_water_primary_hex"),
            "glow": row.get("water_glow_display"),
            "deep_biolum_colour": row.get("deep_water_biolum_primary_colour_display"),
            "exact": bool(row.get("water_profile_exact")),
        },
        "rings": {
            "has_rings": bool(row.get("has_rings")),
            "display": row.get("rings_display"),
            "exact": bool(row.get("rings_prediction_exact")),
        },
        "appearance": {
            "grass": row.get("grass_primary_hex"),
            "grass_alt": row.get("grass_alt_primary_hex"),
            "water": row.get("generated_water_primary_hex"),
            "atmosphere": atmosphere,
        },
        "special_flags": special_flags,
        "exact_planet_portal": row.get("exact_planet_portal_address") or row.get("recommended_portal_address"),
        "planet_seed_hex": row.get("planet_seed_hex"),
        "raw": {
            "weather_index": row.get("weather_index"),
            "weather_mode": row.get("weather_mode"),
            "weather_active": row.get("weather_active"),
            "sentinel_level": row.get("sentinel_level"),
            "resource_level": row.get("resource_level"),
            "life_level": row.get("life_level"),
            "creature_life_level": row.get("creature_life_level"),
            "planet_size": row.get("planet_size"),
        },
    }


def predict_worlds(portal: str, galaxy_index: int) -> dict[str, Any]:
    core = _load_core()
    portal = _norm_portal(portal)
    started = time.perf_counter()
    result = core.predict_system(portal, int(galaxy_index))
    elapsed = time.perf_counter() - started
    rows = [_world_record(core, row) for row in result.get("planet_rows", [])]
    system = result.get("system", {})
    return {
        "status": result.get("status"),
        "atlas_version": "1.0.61",
        "atlas_credit": "ATLAS APF / FIBONACCI",
        "elapsed_seconds": elapsed,
        "planet_count": len(rows),
        "moon_count": sum(1 for w in rows if w["is_moon"]),
        "planet_only_count": sum(1 for w in rows if not w["is_moon"]),
        "default_system_name": system.get("default_procedural_system_name"),
        "star_colour": system.get("colour") or system.get("star_colour"),
        "system_state": system.get("system_state_display") or system.get("system_state_primary"),
        "dominant_race": system.get("dominant_race_display"),
        "economy_type": system.get("economy_type_display"),
        "economy_tier": system.get("economy_tier_display"),
        "conflict_level": system.get("conflict_level_display"),
        "rows": rows,
        "data_scope": "ATLAS APF full deterministic world dossier",
    }

"""Vendored ATLAS APF v1.0.61 world-generation runtime.

Original work: ATLAS APF by FIBONACCI (FIB0N4CC1197).
Used by The Observatory under the author's published permission for original,
free tools based on ATLAS APF documented methods, code, or data with credit.
"""
